export const eventsProjection = [
  {
    dayOfWeek: 1,
    activityType: 'follow',
    count: 10,
  },
  {
    dayOfWeek: 2,
    activityType: 'qualification',
    count: 5,
  },
];
