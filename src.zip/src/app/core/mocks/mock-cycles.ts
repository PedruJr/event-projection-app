import { Cycle } from '../models/cycle.model';

export const mockCycles: Cycle[] = [
  {
    name: 'Prospeccao outbound',
    availableEntities: 5,
    selected: true,
    priority: 'HIGH',
    selectedEntities: 2,
    todayEvents: 4,
    structure: {
      1: { follow: 2, qualification: 3 },
      4: { checkpoint: 1 }
    }
  },
  {
    name: 'Credenciamento',
    availableEntities: 3,
    selected: true,
    priority: 'HIGH',
    selectedEntities: 3,
    todayEvents: 12,
    structure: {
      2: { follow: 1 },
      5: { exploration: 2 }
    }
  },
  {
    name: 'Outbound geral',
    availableEntities: 195,
    selected: true,
    priority: 'MEDIUM',
    selectedEntities: 6,
    todayEvents: 18,
    structure: {
      3: { follow: 1, qualification: 1 },
      4: { checkpoint: 2, exploration: 1 }
    }
  },
  {
    name: 'Ciclo de teste de exclusao',
    availableEntities: 2,
    selected: false,
    priority: 'LOW',
    selectedEntities: 0,
    todayEvents: 0,
    structure: {
      1: { follow: 1 },
      2: { follow: 1 }
    }
  }
];
